class Element {
	int index;
	int value;
	
	public Element(int index, int value){
		this.index = index;
		this.value = value;
	}
	
}